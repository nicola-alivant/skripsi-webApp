<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements FirebaseException
{
}
